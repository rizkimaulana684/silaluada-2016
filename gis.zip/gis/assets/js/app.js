L.mapbox.accessToken = 'pk.eyJ1Ijoic2h6bSIsImEiOiJoT1NuRm0wIn0.SlPjjLaV22Yvq-i1byYCFg';
var map = L.mapbox.map('map').setView([-6.6009458,106.7977458], 13);		

	
/*
var geocoder_control = L.mapbox.geocoderControl('mapbox.places', { position: 'topright', keepOpen: false, autocomplete: true });
map.addControl(geocoder_control);

geocoder_control.on('select', function(object){
    var coord = object.feature.geometry.coordinates;

    L.mapbox.featureLayer({
        type: 'Feature',
        geometry: {
            type: 'Point',
            coordinates: coord
        },
        properties: {
            title: 'Ini Lokasi yang Anda Cari',
            'marker-size': 'large',
            'marker-color': '#BE9A6B',
            'marker-symbol': 'star'
        }
    }).addTo(map);

});
*/
map.zoomControl.setPosition('topright');
L.control.scale().addTo(map);

L.control.layers({
			'Streets': L.mapbox.tileLayer('mapbox.streets').addTo(map),
			'Light': L.mapbox.tileLayer('mapbox.light'),
			'Outdoors': L.mapbox.tileLayer('mapbox.outdoors'),
			'Satellite': L.mapbox.tileLayer('mapbox.satellite'),
			'Emerald': L.mapbox.tileLayer('mapbox.emerald'),
			'Dark': L.mapbox.tileLayer('mapbox.dark')		
		}, {
			'Batas Kecamatan': L.mapbox.featureLayer()
				.loadURL('geojson/rth/adm_kec_kotabogor_warna.geojson'),
			'Batas Kelurahan': L.mapbox.featureLayer()
				.loadURL('geojson/rth/adm_kel_kotabogor_warna.geojson'),
			'Sungai Besar': L.mapbox.featureLayer()
				.loadURL('geojson/rth/sungai_besar.geojson'),		
			'Sungai Kecil': L.mapbox.featureLayer()
				.loadURL('geojson/rth/sungai_kecil.geojson'),
			'RTRW': L.mapbox.featureLayer()
				.loadURL('geojson/ren/polaruang_warna.geojson'),
			'Zona Air Tanah': L.mapbox.featureLayer()
				.loadURL('geojson/zat/zona_airtanah_warna_baru.geojson')		
		}).addTo(map);

//L.Control.Scale({position: 'bottomright'}).addTo(map);	


L.mapbox.featureLayer()
		.loadURL('geojson/rth/adm_kotabogor.geojson')		
		.addTo(map);		

//L.mapbox.featureLayer()
//		.loadURL('geojson/rth/canvas_admkotabogor.geojson')		
//		.addTo(map);		
	
//map.on('popupclose', function(e) {
//    console.log(e.target);
   // map.setView([-6.6009458,106.7977458], 13);
//	map.setView([-6.6009458,106.7977458]);
//});

	
//var groupSungai = new L.LayerGroup();
//        L.mapbox.featureLayer()
//		.loadURL('geojson/sungai_geojson.php').addTo(groupSungai);
		
//var sungai = L.mapbox.featureLayer()
//  .loadURL('geojson/sungai_geojson.php')
//  .on('ready', function() {
//    sungai.eachLayer(function(layer) {
//      map.fitBounds(sungai.getBounds());
//      layer.bindPopup(sungai.features.properties.name);
//    });
//  })
//  .addTo(map);		
		
		
		
var groupCisadane = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/cisadane.geojson').addTo(groupCisadane);
var groupCiliwung = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/ciliwung.geojson').addTo(groupCiliwung);
var groupCidepit = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/cidepit.geojson').addTo(groupCidepit);
var groupCikaret = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/cikaret.geojson').addTo(groupCikaret);
var groupCipakancilan = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/cipakancilan.geojson').addTo(groupCipakancilan);
var groupCibalok = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/cibalok.geojson').addTo(groupCibalok);
var groupCiluar = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/ciluar.geojson').addTo(groupCiluar);
var groupCisindangbarang = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/cisindangbarang.geojson').addTo(groupCisindangbarang);
var groupCiparigi = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/ciparigi.geojson').addTo(groupCiparigi);
var groupCianten = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/cianten.geojson').addTo(groupCianten);		

var groupSumur = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sumur_geojson.php').addTo(groupSumur);
		
var groupSitu = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/situ_baru.geojson').addTo(groupSitu);
var groupSituGede = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/situgede.geojson').addTo(groupSituGede);
var groupSituPanjang = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/situpanjang.geojson').addTo(groupSituPanjang);
var groupSituAnggalena = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/situanggalena.geojson').addTo(groupSituAnggalena);
var groupCerobong = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/cerobong_geojson.php').addTo(groupCerobong);
var groupAmbien = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/ambien_geojson.php').addTo(groupAmbien);
var groupTanah = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/tanah_geojson.php').addTo(groupTanah);
var groupBtiga = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/btiga_geojson.php').addTo(groupBtiga);
var groupLimbahcair = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/limbahcair_geojson.php').addTo(groupLimbahcair);
var groupBiogas = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/biogas_geojson.php').addTo(groupBiogas);
var groupMataair = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/mataair_geojson.php').addTo(groupMataair);
var groupAirtanah = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/airtanah_geojson.php').addTo(groupAirtanah);
var groupPantau = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/pantau_geojson.php').addTo(groupPantau);
var groupResapan = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/resapan_geojson.php').addTo(groupResapan);
var groupImbuhan = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/imbuhan_geojson.php').addTo(groupImbuhan);
var groupHutankota = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sil/hutankota.geojson').addTo(groupHutankota);
var groupSehati = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/sehati_geojson.php').addTo(groupSehati);
var groupKehati = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/kehati_geojson.php').addTo(groupKehati);
var groupPemerhati = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/pemerhati_geojson.php').addTo(groupPemerhati);
var groupKegiatanusaha = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/kegiatanusaha_geojson_baru.php').addTo(groupKegiatanusaha);
var groupUkm = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/ukm_geojson_baru.php').addTo(groupUkm);
var groupAdipura = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/adipura_geojson.php').addTo(groupAdipura);
var groupAdiwiyata = new L.LayerGroup();
        L.mapbox.featureLayer()
		.loadURL('geojson/adiwiyata_geojson.php').addTo(groupAdiwiyata);
		
//Zona Air Tanah
var groupZatKotaBogor = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/zat/zat_kotabogor.geojson').addTo(groupZatKotaBogor);			
var groupZatRusak = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/zat/zat_rusak.geojson').addTo(groupZatRusak);			
var groupZatKritis = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/zat/zat_kritis.geojson').addTo(groupZatKritis);			
var groupZatRawan = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/zat/zat_rawan.geojson').addTo(groupZatRawan);			
var groupZatAman = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/zat/zat_aman.geojson').addTo(groupZatAman);	
		
//Peta Dasar
var groupBatasKecamatan = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/rth/adm_kec_kotabogor_warna.geojson').addTo(groupBatasKecamatan);
var groupBatasKelurahan = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/rth/adm_kel_kotabogor_warna.geojson').addTo(groupBatasKelurahan);		
var groupBadanJalan = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/rth/badanjalan_kotabogor.geojson').addTo(groupBadanJalan);		
var groupSungaiBesar = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/rth/sungai_besar.geojson').addTo(groupSungaiBesar);		
var groupSungaiKecil = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/rth/sungai_kecil.geojson').addTo(groupSungaiKecil);		
var groupRTRW = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/ren/polaruang_warna.geojson').addTo(groupRTRW);	
		

var showSungai = document.getElementById("sungai");
showSungai.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupSungai);	 
       this.className = '';  
    } else {
       map.addLayer(groupSungai);
       this.className = 'active';
	   //map.legendControl.addLegend(legendSungai);
	   document.getElementById("bottomText").innerHTML = "";		   
	   document.getElementById("HeadBottomText").innerHTML = "Data Sungai Kota Bogor";	   
	}
};	   

var showCiliwung = document.getElementById("ciliwung");
showCiliwung.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCiliwung);
       this.className = '';
    } else {
       map.addLayer(groupCiliwung);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";		   
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Ciliwung";
	   load_ciliwung_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Ciliwung";	   
	   load_ciliwung_all();		   
	}
};
var showCibalok = document.getElementById("cibalok");
showCibalok.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCibalok);
       this.className = '';
    } else {
       map.addLayer(groupCibalok);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Cibalok";	
	   load_cibalok_main();	 	   
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Cibalok";	
	   load_cibalok_all();	 
	}
};
var showCiparigi = document.getElementById("ciparigi");
showCiparigi.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCiparigi);
       this.className = '';
    } else {
       map.addLayer(groupCiparigi);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Ciparigi";	
	   load_ciparigi_main();	
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Ciparigi";	   
	   load_ciparigi_all();	 	   
	}
};	
var showCiluar = document.getElementById("ciluar");
showCiluar.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCiluar);
       this.className = '';
    } else {
       map.addLayer(groupCiluar);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Ciluar";	   
	   load_ciluar_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Ciluar";	   
	   load_ciluar_all();	   
	}
};
var showCisadane = document.getElementById("cisadane");
showCisadane.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCisadane);
       this.className = '';
    } else {
       map.addLayer(groupCisadane);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Cisadane";	
	   load_cisadane_main();	
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Cisadane";	   
	   load_cisadane_all();	
	}
};
var showCisindangbarang = document.getElementById("cisindangbarang");
showCisindangbarang.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCisindangbarang);
       this.className = '';
    } else {
       map.addLayer(groupCisindangbarang);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Cisindangbarang";
	   load_cisindangbarang_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Cisindangbarang";	   
	   load_cisindangbarang_all();		   
	}
};
var showCipakancilan = document.getElementById("cipakancilan");
showCipakancilan.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCipakancilan);
       this.className = '';
    } else {
       map.addLayer(groupCipakancilan);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Cipakancilan";	   
	   load_cipakancilan_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Cipakancilan";	   
	   load_cipakancilan_all();
	}
};
var showCianten = document.getElementById("cianten");
showCianten.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCianten);
       this.className = '';
    } else {
       map.addLayer(groupCianten);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Cianten";
	   load_cianten_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Cianten";	   
	   load_cianten_all();	   
	}
};	
var showCidepit = document.getElementById("cidepit");
showCidepit.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCidepit);
       this.className = '';
    } else {
       map.addLayer(groupCidepit);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Cidepit";
	   load_cidepit_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Sungai Cidepit";
	   load_cidepit_all();	 	   
	}
};
var showCikaret = document.getElementById("cikaret");
showCikaret.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCikaret);
       this.className = '';
    } else {
       map.addLayer(groupCikaret);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Sungai Cikaret";
	   load_cikaret();	 	   
	}
};

var showSumur = document.getElementById("sumur");
showSumur.onclick = function(e) {

    if (this.className=='active') {
       map.removeLayer(groupSumur);
       this.className = '';
    } else {
       map.addLayer(groupSumur);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Data Uji Sumur";	   	   
	}
};

var showSitu = document.getElementById("situ");
showSitu.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupSitu);
       this.className = '';
    } else {
       map.addLayer(groupSitu);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Situ";	   
    }
};
var showSituGede = document.getElementById("situgede");
showSituGede.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupSituGede);
       this.className = '';
    } else {
       map.addLayer(groupSituGede);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Situ Gede";	
	   load_situgede_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Situ Gede";
	   load_situgede_all(); 
    }
};
var showSituPanjang = document.getElementById("situpanjang");
showSituPanjang.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupSituPanjang);
       this.className = '';
    } else {
       map.addLayer(groupSituPanjang);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Situ Panjang";	
	   load_situpanjang_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Situ Panjang";
	   load_situpanjang_all(); 	   
    }
};
var showSituAnggalena = document.getElementById("situanggalena");
showSituAnggalena.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupSituAnggalena);
       this.className = '';
    } else {
       map.addLayer(groupSituAnggalena);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Situ Anggalena";
	   load_situanggalena_main();	 
	   document.getElementById("DetailText").innerHTML = "";	
	   document.getElementById("HeadDetailText").innerHTML = "Hasil Uji Situ Anggalena";
	   load_situanggalena_all(); 	   
    }
};
var showCerobong = document.getElementById("cerobong");
showCerobong.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupCerobong);
       this.className = '';
    } else {
       map.addLayer(groupCerobong);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Emisi Cerobong";	   	   
    }
};
var showAmbien = document.getElementById("ambien");
showAmbien.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupAmbien);
       this.className = '';
    } else {
       map.addLayer(groupAmbien);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Emisi Ambien";	   	   
    }
};
var showTanah = document.getElementById("tanah");
showTanah.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupTanah);
       this.className = '';
    } else {
       map.addLayer(groupTanah);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Tanah";	   	   
    }
};
var showBtiga = document.getElementById("btiga");
showBtiga.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupBtiga);
       this.className = '';
    } else {
       map.addLayer(groupBtiga);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Limbah B3";	   	   
    }
};
var showLimbahcair = document.getElementById("limbahcair");
showLimbahcair.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupLimbahcair);
       this.className = '';
    } else {
       map.addLayer(groupLimbahcair);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Hasil Uji Limbah Cair";	   	   
    }
};
var showBiogas = document.getElementById("biogas");
showBiogas.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupBiogas);
       this.className = '';
    } else {
       map.addLayer(groupBiogas);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Pembangunan Biogas";	   	   
    }
};
var showMataair = document.getElementById("mataair");
showMataair.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupMataair);
       this.className = '';
    } else {
       map.addLayer(groupMataair);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Mata Air";	 
    }
};
var showAirtanah = document.getElementById("airtanah");
showAirtanah.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupAirtanah);
       this.className = '';
    } else {
       map.addLayer(groupAirtanah);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Perusahaan Pengguna Air Tanah";	   
    }
};
var showPantau = document.getElementById("pantau");
showPantau.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupPantau);
       this.className = '';
    } else {
       map.addLayer(groupPantau);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Sumur Pantau";	   	   
    }
};
var showResapan = document.getElementById("resapan");
showResapan.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupResapan);
       this.className = '';
    } else {
       map.addLayer(groupResapan);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Sumur Resapan";	   	 	   
    }
};
var showImbuhan = document.getElementById("imbuhan");
showImbuhan.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupImbuhan);
       this.className = '';
    } else {
       map.addLayer(groupImbuhan);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Sumur Imbuhan";	   	 	   
    }
};
var showHutankota = document.getElementById("hutankota");
showHutankota.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupHutankota);
       this.className = '';
    } else {
       map.addLayer(groupHutankota);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Hutan Kota";	   	 	   
    }
};
var showSehati = document.getElementById("sehati");
showSehati.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupSehati);
       this.className = '';
    } else {
       map.addLayer(groupSehati);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Sekolah Keanekaragaman Hayati";	   	 	   
    }
};
var showKehati = document.getElementById("kehati");
showKehati.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupKehati);
       this.className = '';
    } else {
       map.addLayer(groupKehati);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Kelurahan Keanekaragaman Hayati";	   	 	   
    }
};
var showPemerhati = document.getElementById("pemerhati");
showPemerhati.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupPemerhati);
       this.className = '';
    } else {
       map.addLayer(groupPemerhati);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Perusahaan Keanekaragaman Hayati";		   
    }
};
var showKegiatanusaha = document.getElementById("kegiatanusaha");
showKegiatanusaha.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupKegiatanusaha);
       this.className = '';
    } else {
       map.addLayer(groupKegiatanusaha);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Kegiatan Usaha";		   
    }
};
var showUkm = document.getElementById("ukm");
showUkm.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupUkm);
       this.className = '';
    } else {
       map.addLayer(groupUkm);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi UKM";		   
    }
};
var showAdipura = document.getElementById("adipura");
showAdipura.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupAdipura);
       this.className = '';
    } else {
       map.addLayer(groupAdipura);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Titik Pantau Adipura";		   
    }
};
var showAdiwiyata = document.getElementById("adiwiyata");
showAdiwiyata.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupAdiwiyata);
       this.className = '';
    } else {
       map.addLayer(groupAdiwiyata);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Lokasi Sekolahan Penerima Penghargaan Adiwiyata";		   
    }
};	

//Zona Air Tanah
var showZatKotaBogor = document.getElementById("zat_kotabogor");
showZatKotaBogor.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupZatKotaBogor);
       this.className = '';
	} else {
       map.addLayer(groupZatKotaBogor);
       this.className = 'active';     
	   map.removeLayer(groupZatRusak);	   
	   var showZatRusak = document.getElementById("zat_rusak");	   
       showZatRusak.className = '';	
	   map.removeLayer(groupZatKritis);	   
	   var showZatKritis = document.getElementById("zat_kritis");	   
       showZatKritis.className = '';		   
	   map.removeLayer(groupZatRawan);	   
	   var showZatRawan = document.getElementById("zat_rawan");	   
       showZatRawan.className = '';	   
	   map.removeLayer(groupZatAman);	   
	   var showZatAman = document.getElementById("zat_aman");	   
       showZatAman.className = '';	
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Peta Konservasi Air Tanah Kota Bogor Tahun 2011";
	   load_zat();	
	}   
};
var showZatRusak = document.getElementById("zat_rusak");
showZatRusak.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupZatRusak);
       this.className = '';
	} else {
       map.addLayer(groupZatRusak);
       this.className = 'active';   
	   map.removeLayer(groupZatKotaBogor);	   
	   var showZatKotaBogor = document.getElementById("zat_kotabogor");	   
       showZatKotaBogor.className = '';	
	   map.removeLayer(groupZatKritis);	   
	   var showZatKritis = document.getElementById("zat_kritis");	   
       showZatKritis.className = '';		   
	   map.removeLayer(groupZatRawan);	   
	   var showZatRawan = document.getElementById("zat_rawan");	   
       showZatRawan.className = '';	   
	   map.removeLayer(groupZatAman);	   
	   var showZatAman = document.getElementById("zat_aman");	   
       showZatAman.className = '';
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Peta Zona Rusak - Konservasi Air Tanah Kota Bogor Tahun 2011";
	   load_zat();	  
	}   
};
var showZatKritis = document.getElementById("zat_kritis");
showZatKritis.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupZatKritis);
       this.className = '';
	} else {
       map.addLayer(groupZatKritis);
       this.className = 'active';   
	   map.removeLayer(groupZatKotaBogor);	   
	   var showZatKotaBogor = document.getElementById("zat_kotabogor");	   
       showZatKotaBogor.className = '';	
	   map.removeLayer(groupZatRusak);	   
	   var showZatRusak = document.getElementById("zat_rusak");	   
       showZatRusak.className = '';		   
	   map.removeLayer(groupZatRawan);	   
	   var showZatRawan = document.getElementById("zat_rawan");	   
       showZatRawan.className = '';	   
	   map.removeLayer(groupZatAman);	   
	   var showZatAman = document.getElementById("zat_aman");	   
       showZatAman.className = '';
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Peta Zona Kritis - Konservasi Air Tanah Kota Bogor Tahun 2011";
	   load_zat();		   
	}   
};
var showZatRawan = document.getElementById("zat_rawan");
showZatRawan.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupZatRawan);
       this.className = '';
	} else {
       map.addLayer(groupZatRawan);
       this.className = 'active';
	   map.removeLayer(groupZatKotaBogor);	   
	   var showZatKotaBogor = document.getElementById("zat_kotabogor");	   
       showZatKotaBogor.className = '';	
	   map.removeLayer(groupZatKritis);	   
	   var showZatKritis = document.getElementById("zat_kritis");	   
       showZatKritis.className = '';		   
	   map.removeLayer(groupZatRusak);	   
	   var showZatRusak = document.getElementById("zat_rusak");	   
       showZatRusak.className = '';	   
	   map.removeLayer(groupZatAman);	   
	   var showZatAman = document.getElementById("zat_aman");	   
       showZatAman.className = ''; 
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Peta Zona Rawan - Konservasi Air Tanah Kota Bogor Tahun 2011";
	   load_zat();	
	}   
};
var showZatAman = document.getElementById("zat_aman");
showZatAman.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupZatAman);
       this.className = '';
	} else {
       map.addLayer(groupZatAman);
       this.className = 'active';
	   map.removeLayer(groupZatKotaBogor);	   
	   var showZatKotaBogor = document.getElementById("zat_kotabogor");	   
       showZatKotaBogor.className = '';	
	   map.removeLayer(groupZatKritis);	   
	   var showZatKritis = document.getElementById("zat_kritis");	   
       showZatKritis.className = '';		   
	   map.removeLayer(groupZatRawan);	   
	   var showZatRawan = document.getElementById("zat_rawan");	   
       showZatRawan.className = '';	   
	   map.removeLayer(groupZatRusak);	   
	   var showZatRusak = document.getElementById("zat_rusak");	   
       showZatRusak.className = '';	 
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Peta Zona Aman - Konservasi Air Tanah Kota Bogor Tahun 2011";
	   load_zat();	 
	}   
};

//Peta Dasar
var showBatasKecamatan = document.getElementById("bataskecamatan");
showBatasKecamatan.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupBatasKecamatan);
       this.className = '';
    } else {
       map.addLayer(groupBatasKecamatan);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Batas Kecamatan";	   
    }
};	
var showBatasKelurahan = document.getElementById("bataskelurahan");
showBatasKelurahan.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupBatasKelurahan);
       this.className = '';
    } else {
       map.addLayer(groupBatasKelurahan);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Batas Kelurahan";	   
    }
};
var showBadanJalan = document.getElementById("badanjalan");
showBadanJalan.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupBadanJalan);
       this.className = '';
    } else {
       map.addLayer(groupBadanJalan);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";	   
	   document.getElementById("HeadBottomText").innerHTML = "Badan Jalan";	   
    }
};	
var showSungaiBesar = document.getElementById("sungaibesar");
showSungaiBesar.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupSungaiBesar);
       this.className = '';
    } else {
       map.addLayer(groupSungaiBesar);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";		   
	   document.getElementById("HeadBottomText").innerHTML = "Data Sungai Besar";	   
    }
};
var showSungaiKecil = document.getElementById("sungaikecil");
showSungaiKecil.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupSungaiKecil);
       this.className = '';
    } else {
       map.addLayer(groupSungaiKecil);
       this.className = 'active';
	   document.getElementById("bottomText").innerHTML = "";		   
	   document.getElementById("HeadBottomText").innerHTML = "Data Sungai Kecil";	   
    }
};		
var showRTRW = document.getElementById("rtrw");
showRTRW.onclick = function(e) {
    if (this.className=='active') {
       map.removeLayer(groupRTRW);
       this.className = '';
    } else {
       map.addLayer(groupRTRW);
       this.className = 'active'; 
	   document.getElementById("bottomText").innerHTML = "";		   
	   document.getElementById("HeadBottomText").innerHTML = "Data Rencana Tata Ruang Wilayah";
	   load_rtrw();
	   
    }
};		


//Filter Peta
var groupFilterKotaBogor = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/filter/kotabogor.geojson').addTo(groupFilterKotaBogor);
var groupFilterBogorUtara = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/filter/kabbogor_bogorutara.geojson').addTo(groupFilterBogorUtara);
var groupFilterBogorSelatan = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/filter/kabbogor_bogorselatan.geojson').addTo(groupFilterBogorSelatan);
var groupFilterBogorBarat = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/filter/kabbogor_bogorbarat.geojson').addTo(groupFilterBogorBarat);
var groupFilterBogorTimur = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/filter/kabbogor_bogortimur.geojson').addTo(groupFilterBogorTimur);
var groupFilterBogorTengah = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/filter/kabbogor_bogortengah.geojson').addTo(groupFilterBogorTengah);
var groupFilterTanahSareal = new L.LayerGroup();
		L.mapbox.featureLayer()
		.loadURL('geojson/filter/kabbogor_tanahsareal.geojson').addTo(groupFilterTanahSareal);	
		
//Show Hide Filter Peta 
var showFilterKotaBogor = document.getElementById("kotabogor");
showFilterKotaBogor.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupFilterKotaBogor);
       this.className = '';
	} else {		
       map.addLayer(groupFilterKotaBogor);
       showFilterKotaBogor.className = 'active';
	   map.removeLayer(groupFilterBogorUtara);	
	   var showFilterBogorUtara = document.getElementById("bogorutara");
       showFilterBogorUtara.className = '';	 
	   map.removeLayer(groupFilterBogorSelatan);	   
	   var showFilterBogorSelatan = document.getElementById("bogorselatan");	   
       showFilterBogorSelatan.className = '';	 	   
	   map.removeLayer(groupFilterBogorBarat);	   
	   var showFilterBogorBarat = document.getElementById("bogorbarat");	   
       showFilterBogorBarat.className = '';	
	   map.removeLayer(groupFilterBogorTimur);	   
	   var showFilterBogorTimur = document.getElementById("bogortimur");	   
       showFilterBogorTimur.className = '';	
	   map.removeLayer(groupFilterBogorTengah);	   
	   var showFilterBogorTengah = document.getElementById("bogortengah");	   
       showFilterBogorTengah.className = '';	
	   map.removeLayer(groupFilterTanahSareal);	   
	   var showFilterTanahSareal = document.getElementById("tanahsareal");	   
       showFilterTanahSareal.className = '';	
	}	
};

var showFilterBogorUtara = document.getElementById("bogorutara");
showFilterBogorUtara.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupFilterBogorUtara);
       this.className = '';
	} else {
       map.addLayer(groupFilterBogorUtara);
       this.className = 'active';
	   map.removeLayer(groupFilterKotaBogor);
	   var showFilterKotaBogor = document.getElementById("kotabogor");
       showFilterKotaBogor.className = '';	 
	   map.removeLayer(groupFilterBogorSelatan);
	   var showFilterBogorSelatan = document.getElementById("bogorselatan");	   
       showFilterBogorSelatan.className = '';	 	   
	   map.removeLayer(groupFilterBogorBarat);
	   var showFilterBogorBarat = document.getElementById("bogorbarat");	   
       showFilterBogorBarat.className = '';	
	   map.removeLayer(groupFilterBogorTimur);
	   var showFilterBogorTimur = document.getElementById("bogortimur");	   
       showFilterBogorTimur.className = '';	
	   map.removeLayer(groupFilterBogorTengah);
	   var showFilterBogorTengah = document.getElementById("bogortengah");	   
       showFilterBogorTengah.className = '';	
	   map.removeLayer(groupFilterTanahSareal);
	   var showFilterTanahSareal = document.getElementById("tanahsareal");	   
       showFilterTanahSareal.className = '';
	}   
};

var showFilterBogorSelatan = document.getElementById("bogorselatan");
showFilterBogorSelatan.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupFilterBogorSelatan);
       this.className = '';
	} else {
       map.addLayer(groupFilterBogorSelatan);
       this.className = 'active';
	   map.removeLayer(groupFilterKotaBogor);
	   var showFilterKotaBogor = document.getElementById("kotabogor");
       showFilterKotaBogor.className = '';	 
	   map.removeLayer(groupFilterBogorUtara);
	   var showFilterBogorUtara = document.getElementById("bogorutara");	   
       showFilterBogorUtara.className = '';	 	   
	   map.removeLayer(groupFilterBogorBarat);
	   var showFilterBogorBarat = document.getElementById("bogorbarat");	   
       showFilterBogorBarat.className = '';	
	   map.removeLayer(groupFilterBogorTimur);
	   var showFilterBogorTimur = document.getElementById("bogortimur");	   
       showFilterBogorTimur.className = '';	
	   map.removeLayer(groupFilterBogorTengah);
	   var showFilterBogorTengah = document.getElementById("bogortengah");	   
       showFilterBogorTengah.className = '';	
	   map.removeLayer(groupFilterTanahSareal);
	   var showFilterTanahSareal = document.getElementById("tanahsareal");	   
       showFilterTanahSareal.className = '';
	}   
};
var showFilterBogorBarat = document.getElementById("bogorbarat");
showFilterBogorBarat.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupFilterBogorBarat);
       this.className = '';
	} else {
       map.addLayer(groupFilterBogorBarat);
       this.className = 'active';
	   map.removeLayer(groupFilterKotaBogor);
	   var showFilterKotaBogor = document.getElementById("kotabogor");
       showFilterKotaBogor.className = '';	 
	   map.removeLayer(groupFilterBogorSelatan);
	   var showFilterBogorSelatan = document.getElementById("bogorselatan");	   
       showFilterBogorSelatan.className = '';	 	   
	   map.removeLayer(groupFilterBogorUtara);
	   var showFilterBogorUtara = document.getElementById("bogorutara");	   
       showFilterBogorUtara.className = '';	
	   map.removeLayer(groupFilterBogorTimur);
	   var showFilterBogorTimur = document.getElementById("bogortimur");	   
       showFilterBogorTimur.className = '';	
	   map.removeLayer(groupFilterBogorTengah);
	   var showFilterBogorTengah = document.getElementById("bogortengah");	   
       showFilterBogorTengah.className = '';	
	   map.removeLayer(groupFilterTanahSareal);
	   var showFilterTanahSareal = document.getElementById("tanahsareal");	   
       showFilterTanahSareal.className = '';
	}   
};
var showFilterBogorTimur = document.getElementById("bogortimur");
showFilterBogorTimur.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupFilterBogorTimur);
       this.className = '';
	} else {
       map.addLayer(groupFilterBogorTimur);
       this.className = 'active';
	   map.removeLayer(groupFilterKotaBogor);
	   var showFilterKotaBogor = document.getElementById("kotabogor");
       showFilterKotaBogor.className = '';	 
	   map.removeLayer(groupFilterBogorSelatan);
	   var showFilterBogorSelatan = document.getElementById("bogorselatan");	   
       showFilterBogorSelatan.className = '';	 	   
	   map.removeLayer(groupFilterBogorBarat);
	   var showFilterBogorBarat = document.getElementById("bogorbarat");	   
       showFilterBogorBarat.className = '';	
	   map.removeLayer(groupFilterBogorUtara);
	   var showFilterBogorUtara = document.getElementById("bogorutara");	   
       showFilterBogorUtara.className = '';	
	   map.removeLayer(groupFilterBogorTengah);
	   var showFilterBogorTengah = document.getElementById("bogortengah");	   
       showFilterBogorTengah.className = '';	
	   map.removeLayer(groupFilterTanahSareal);
	   var showFilterTanahSareal = document.getElementById("tanahsareal");	   
       showFilterTanahSareal.className = '';
	}   
};
var showFilterBogorTengah = document.getElementById("bogortengah");
showFilterBogorTengah.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupFilterBogorTengah);
       this.className = '';
	} else {
       map.addLayer(groupFilterBogorTengah);
       this.className = 'active';
	   map.removeLayer(groupFilterKotaBogor);
	   var showFilterKotaBogor = document.getElementById("kotabogor");
       showFilterKotaBogor.className = '';	 
	   map.removeLayer(groupFilterBogorSelatan);
	   var showFilterBogorSelatan = document.getElementById("bogorselatan");	   
       showFilterBogorSelatan.className = '';	 	   
	   map.removeLayer(groupFilterBogorBarat);
	   var showFilterBogorBarat = document.getElementById("bogorbarat");	   
       showFilterBogorBarat.className = '';	
	   map.removeLayer(groupFilterBogorTimur);
	   var showFilterBogorTimur = document.getElementById("bogortimur");	   
       showFilterBogorTimur.className = '';	
	   map.removeLayer(groupFilterBogorUtara);
	   var showFilterBogorUtara = document.getElementById("bogorutara");	   
       showFilterBogorUtara.className = '';	
	   map.removeLayer(groupFilterTanahSareal);
	   var showFilterTanahSareal = document.getElementById("tanahsareal");	   
       showFilterTanahSareal.className = '';
	}   
};
var showFilterTanahSareal = document.getElementById("tanahsareal");
showFilterTanahSareal.onclick = function(e) {
	if (this.className=='active') {
	   map.removeLayer(groupFilterTanahSareal);
       this.className = '';
	} else {
       map.addLayer(groupFilterTanahSareal);
       this.className = 'active';
	   map.removeLayer(groupFilterKotaBogor);
	   var showFilterKotaBogor = document.getElementById("kotabogor");
       showFilterKotaBogor.className = '';	 
	   map.removeLayer(groupFilterBogorSelatan);
	   var showFilterBogorSelatan = document.getElementById("bogorselatan");	   
       showFilterBogorSelatan.className = '';	 	   
	   map.removeLayer(groupFilterBogorBarat);
	   var showFilterBogorBarat = document.getElementById("bogorbarat");	   
       showFilterBogorBarat.className = '';	
	   map.removeLayer(groupFilterBogorTimur);
	   var showFilterBogorTimur = document.getElementById("bogortimur");	   
       showFilterBogorTimur.className = '';	
	   map.removeLayer(groupFilterBogorTengah);
	   var showFilterBogorTengah = document.getElementById("bogortengah");	   
       showFilterBogorTengah.className = '';	
	   map.removeLayer(groupFilterBogorUtara);
	   var showFilterBogorUtara = document.getElementById("bogorutara");	   
       showFilterBogorUtara.className = '';  
	}   
    
};

function load_rtrw(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="info/info_rtrw.php" style="width:100%; height: 100%;"></object>';
}
function load_zat(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="info/info_zat.php" style="width:100%; height: 100%;"></object>';
}
function load_ciliwung_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/ciliwung_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_ciliwung_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/ciliwung_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_cibalok_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/cibalok_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_cibalok_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/cibalok_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_ciparigi_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/ciparigi_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_ciparigi_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/ciparigi_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_ciluar_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/ciluar_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_ciluar_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/ciluar_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_cisadane_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/cisadane_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_cisadane_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/cisadane_all.htm" style="width:100%; height: 100%;"></object>';
}

function load_cisindangbarang_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/cisindangbarang_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_cisindangbarang_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/cisindangbarang_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_cipakancilan_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/cipakancilan_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_cipakancilan_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/cipakancilan_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_cianten_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/cianten_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_cianten_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/cianten_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_cidepit_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/cidepit_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_cidepit_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/sungai/cidepit_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_cikaret(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/sungai/sungai_cikaret_main.htm" style="width:100%; height: 100%;"></object>';
}

//Situ
function load_situgede_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/situ/situgede_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_situgede_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/situ/situgede_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_situpanjang_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/situ/situpanjang_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_situpanjang_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/situ/situpanjang_all.htm" style="width:100%; height: 100%;"></object>';
}
function load_situanggalena_main(){
document.getElementById("bottomText").innerHTML='<object type="text/html" data="chart/situ/situanggalena_main.htm" style="width:100%; height: 100%;"></object>';
}
function load_situanggalena_all(){
document.getElementById("DetailText").innerHTML='<object type="text/html" data="chart/situ/situanggalena_all.htm" style="width:100%; height: 100%;"></object>';
}