
document.getElementById("bottomText").innerHTML = "New text!";
